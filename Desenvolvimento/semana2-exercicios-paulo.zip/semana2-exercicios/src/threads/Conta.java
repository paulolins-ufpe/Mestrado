package threads;

public class Conta {
	private double saldo;
	private String numeroConta;

	public Conta(String numeroConta, double saldoInicial) {
		this.numeroConta = numeroConta;
		this.saldo = saldoInicial;
	}

	public double getSaldo() {
		return saldo;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public  void creditar(double valor) {
		saldo += valor;
        System.out.printf("%s: Creditou %f\n", Thread.currentThread().getName(), valor);
	}

	public  void debitar(double valor) {
		saldo -= valor;
        System.out.printf("%s: Debitou %f\n", Thread.currentThread().getName(), valor);  
        
	}
	
	public synchronized void transferir(Conta destino, double valor) {
		try {
		debitar(valor);
		destino.creditar(valor);
		
		Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

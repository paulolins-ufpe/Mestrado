package threads;

public class Main {

	public static void main(String[] args) {
		
		//Crie mais contas com número e saldo inicial variado
		final Conta c1 = new Conta("12345-678", 1000.00);
		final Conta c2 = new Conta("23456-789", 2000.05);
		final Conta c3 = new Conta("00456-333", 2020.00);
		final Conta c4 = new Conta("00123-222", 90.00);
		
		/*final Conta c5 = new Conta("20456-000", 60.00);
		final Conta c6 = new Conta("20006-123", 10550.00);
		final Conta c7 = new Conta("23000-012", 120.03);*/
		
		// Crie novas Threads, no formato similar ao das duas abaixo, 
		// (thread1 e thread2) usando lambda expressions
		// Coloque valores e operações aleatórias
		Thread thread1 = new Thread(new Runnable() {
			@Override
			public void run() {				
				c1.creditar(300.00);
				c1.debitar(50.00);
				c1.transferir(c2, 500.00);
				System.out.println("Transação finalizada na conta "+ c1.getNumeroConta()+"Saldo na conta "+ c1.getSaldo());				
			}
		});

		Thread thread2 = new Thread(new Runnable() {
			@Override
			public void run() {
				c2.creditar(100.00);
				c2.debitar(450.00);
				c2.transferir(c3, 1500);
				System.out.println("Transação finalizada na conta "+ c2.getNumeroConta()+"Saldo na conta "+ c2.getSaldo());
				
			}
		});
		
				
		Runnable r3 = () ->{			
				c3.creditar(100.00);
				c3.debitar(450.00);
				c3.transferir(c4, 1500);
				System.out.println("Transação finalizada na conta "+ c3.getNumeroConta()+"Saldo na conta "+ c3.getSaldo());
				
		};
		Thread thread3 = new Thread(r3);
		
		
		Runnable r4 = () ->{
				c4.creditar(100.00);
				c4.debitar(450.00);
				c4.transferir(c1, 500);
				System.out.println("Transação finalizada na conta "+ c4.getNumeroConta()+"  ----Saldo na conta "+ c4.getSaldo());
				
		};
			
		Thread thread4 = new Thread(r4);
		
		//inicie aqui as novas threads criadas
		thread1.start();
		thread2.start();
		thread3.start();
		thread4.start();
		
		// Altere a classe Conta de forma a introduzir mecanismos de 
		// sincronização para evitar que as threads intercalem durante uma
		// transferência (método transferir)

		//Implementado syncronize no m�todo Transferir
		
	}
}

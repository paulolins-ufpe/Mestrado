package lambda;

import java.util.function.Function;


@FunctionalInterface
abstract interface Operacao{
	String aCadaDoisCaracteres(String s);
	
	public static String recebeFuncaoLambda(String string,Function<String,String> funcao) {
		return funcao.apply(string);
	}
}


public class Main {
	
	// Original : M�todo do Professor
	public static String aCadaDoisCaracteres(String s) {
		StringBuilder resultado = new StringBuilder();
		for (int i = 0; i < s.length(); i++) {
			if (i % 2 == 1) {
				resultado.append(s.charAt(i));
			}
		}
		return resultado.toString();
	}

	public static void main(String[] args) {
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				String minhaString = "Vamos dividir esta string em um array";
				String[] partes = minhaString.split(" ");
				for (String parte : partes) {
					System.out.println(parte);
				}
			}
		};
		//Para Testar a primeira
		//new Thread(runnable).start();		
		// Transforme o código acima em uma lambda expression, atribuindo o
		// resultado à variável abaixo				
		//Runnable runnable1;
		
		//Editado - Paulo Lins		
		Runnable runnable1 =() -> {				
				String[] partes = "Vamos dividir esta string em um array".split(" ");
				for (String parte : partes) {
					System.out.println(parte);
			}			
		};
		System.out.println("Lambda Expressions--");
		runnable1.run();		
		
		// Escreva o método 'aCadaDoisCaracteres' como uma expressão lambda, 
		// atribuindo o resultado à variável abaixo
		//LAMBDA		
		//Editado - Paulo Lins	
		Operacao LAMBDA = (String s) -> {
			StringBuilder resultado = new StringBuilder();
			for (int i = 0; i < s.length(); i++) {
				if (i % 2 == 1) {
					resultado.append(s.charAt(i));
				}
			}
			return resultado.toString();			
		};		
		System.out.println(LAMBDA.aCadaDoisCaracteres("a Cada Dois Caracteres"));		
		
		// Escreva o código que chama a função lambdaFun, passando alguma String 
		// como argumento, conforme rascunho em comentário abaixo:		
		// String resultado = lambdaFun.ALGUM_METODO("1234567890"); 
		// System.out.println(resultado);
		//Editado - Paulo Lins
		Function<String, String> lambdaFun = (String s) -> {return s;};
		String resultado = lambdaFun.apply("123456789");
		System.out.println("lambdaFun : "+resultado);
		
		// Crie um novo método que recebe uma função lambda que transforma String
		// em String (vide o tipo definido acima para lambdaFun) e retorna o 
		// resultado da aplicação da função em uma String 
		//String resultado2 = recebeFuncaoLambda(lambdaFun, "1234567890");
		//System.out.println(resultado2);
		//Editado - Paulo Lins
		String resultado2 = Operacao.recebeFuncaoLambda("Texto", lambdaFun);
		System.out.println("recebeFuncaoLambda : "+resultado2);
		
	}
	
}
